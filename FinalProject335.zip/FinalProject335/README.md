Submitted by: Carson Hagman (directory id: chagman)
Group Members: Carson Hagman (chagman)
App Description: Generate a random joke, submit your own joke, delete your last submitted joke, and see all joke submissions in this beautiful webpage.
YouTube Video Link: 
APIs: "https://official-joke-api.appspot.com/random_joke"
Contact Email:  chagman@terpmail.umd.edu
Website URL: 